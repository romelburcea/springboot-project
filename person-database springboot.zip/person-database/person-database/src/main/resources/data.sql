create table if not exists person (
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    name varchar(255)
);