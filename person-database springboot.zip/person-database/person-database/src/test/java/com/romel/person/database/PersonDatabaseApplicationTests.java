package com.romel.person.database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
